CITRIX_AWS_PRODUCTS = {
    "Citrix ADC VPX - Customer Licensed": "63425ded-82f0-4b54-8cdd-6ec8b94bd4f8",
}
