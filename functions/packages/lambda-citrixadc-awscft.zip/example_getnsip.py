from barbarika.citrixadc import CitrixADC

NSIP = "13.235.218.114"
DEFAULT_PASSWORD = "notnsroot"
NEW_PASSWORD = "nsroot1"

adc = CitrixADC(nsip=NSIP, nsuser="nsroot", default_password=DEFAULT_PASSWORD, new_password=NEW_PASSWORD,)

print(adc.get_nsip())
